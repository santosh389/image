export interface ImageDimensions {
  width: number;
  height: number;
}

export interface ImageDetails {
  file: File | null;
  url: string;
  format: string;
  size: number;
  dimensions: ImageDimensions;
  name: string;
}

/**
 * Gets image details from a File object, including dimensions
 */
export async function getImageDetails(file: File): Promise<ImageDetails> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    
    img.onload = () => {
      // Get file format from the file extension
      const format = file.name.split('.').pop()?.toLowerCase() || 'unknown';
      
      const details: ImageDetails = {
        file,
        url,
        format,
        size: file.size,
        dimensions: {
          width: img.width,
          height: img.height,
        },
        name: file.name,
      };
      
      resolve(details);
    };
    
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load image'));
    };
    
    img.src = url;
  });
}

/**
 * Format file size for display (e.g. "2.4 MB")
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) {
    return bytes + ' B';
  } else if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(1) + ' KB';
  } else {
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }
}
