import React from "react";
import Header from "@/components/Header";
import ImageConverter from "@/components/ImageConverter";
import Features from "@/components/Features";
import SupportedFormats from "@/components/SupportedFormats";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          {/* Hero Section */}
          <section className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
              Convert Image Formats in Seconds
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto mb-6">
              Upload your image and convert it to any format you need. Fast, secure, and completely free.
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-sm">
              <div className="px-3 py-1 bg-gray-100 rounded-full">JPG</div>
              <div className="px-3 py-1 bg-gray-100 rounded-full">PNG</div>
              <div className="px-3 py-1 bg-gray-100 rounded-full">WEBP</div>
              <div className="px-3 py-1 bg-gray-100 rounded-full">GIF</div>
              <div className="px-3 py-1 bg-gray-100 rounded-full">SVG</div>
              <div className="px-3 py-1 bg-gray-100 rounded-full">TIFF</div>
              <div className="px-3 py-1 bg-gray-100 rounded-full">BMP</div>
              <div className="px-3 py-1 bg-gray-100 rounded-full">ICO</div>
            </div>
          </section>
          
          <ImageConverter />
          <Features />
          <SupportedFormats />
          <FAQ />
        </div>
      </main>
      <Footer />
    </div>
  );
}
