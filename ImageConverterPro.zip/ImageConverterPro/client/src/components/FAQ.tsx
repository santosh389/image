import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface FAQItem {
  question: string;
  answer: string;
}

export default function FAQ() {
  const faqItems: FAQItem[] = [
    {
      question: "Is this service completely free?",
      answer: "Yes, our basic image conversion service is completely free to use with no hidden fees.",
    },
    {
      question: "Are my images secure?",
      answer: "We process your images directly in your browser whenever possible. For complex conversions that require server processing, we delete all images immediately after conversion.",
    },
    {
      question: "What is the maximum file size?",
      answer: "Free users can convert images up to 10MB in size.",
    },
    {
      question: "How is image quality affected by conversion?",
      answer: "Our default settings optimize for the best balance of quality and file size. You can adjust the quality slider for more control over the output.",
    },
  ];

  return (
    <section className="max-w-4xl mx-auto mt-16 mb-16" id="faq">
      <h2 className="text-2xl font-bold text-center mb-10">
        Frequently Asked Questions
      </h2>

      <Accordion type="single" collapsible className="space-y-4">
        {faqItems.map((item, index) => (
          <AccordionItem 
            key={index} 
            value={`item-${index}`}
            className="bg-white p-6 rounded-lg shadow-sm"
          >
            <AccordionTrigger className="font-semibold text-lg">
              {item.question}
            </AccordionTrigger>
            <AccordionContent className="text-gray-600 pt-2">
              {item.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
}
