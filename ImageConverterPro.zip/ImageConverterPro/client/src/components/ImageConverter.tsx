import React, { useState } from "react";
import ImageUploader from "./ImageUploader";
import ImageEditor from "./ImageEditor";
import { ImageDetails } from "@/lib/imageUtils";

export default function ImageConverter() {
  const [isUploaded, setIsUploaded] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<ImageDetails | null>(null);
  const [convertedImage, setConvertedImage] = useState<ImageDetails | null>(null);

  const handleImageUpload = (imageDetails: ImageDetails) => {
    setUploadedImage(imageDetails);
    setIsUploaded(true);
  };

  const handleConvertedImage = (imageDetails: ImageDetails) => {
    setConvertedImage(imageDetails);
  };

  const resetConverter = () => {
    setUploadedImage(null);
    setConvertedImage(null);
    setIsUploaded(false);
  };

  return (
    <section className="max-w-4xl mx-auto mb-12">
      {!isUploaded ? (
        <ImageUploader onImageUpload={handleImageUpload} />
      ) : (
        <ImageEditor 
          originalImage={uploadedImage!} 
          onConvert={handleConvertedImage} 
          onReset={resetConverter}
          convertedImage={convertedImage}
        />
      )}
    </section>
  );
}
