import React, { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, AlertCircle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getImageDetails, ImageDetails } from "@/lib/imageUtils";

interface ImageUploaderProps {
  onImageUpload: (imageDetails: ImageDetails) => void;
}

export default function ImageUploader({ onImageUpload }: ImageUploaderProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      if (acceptedFiles.length === 0) return;

      const file = acceptedFiles[0];

      // Check if file is an image
      if (!file.type.startsWith("image/")) {
        setError("Selected file is not an image.");
        return;
      }

      // Check file size (10MB limit)
      if (file.size > 10 * 1024 * 1024) {
        setError("File size exceeds the 10MB limit.");
        return;
      }

      try {
        setError(null);
        setIsLoading(true);

        // Process the image to get details
        const imageDetails = await getImageDetails(file);
        
        setIsLoading(false);
        onImageUpload(imageDetails);
        
        toast({
          title: "Image uploaded successfully",
          description: "Your image is ready to be converted.",
        });
      } catch (err) {
        setIsLoading(false);
        setError("Failed to process image. Please try again.");
        console.error(err);
      }
    },
    [onImageUpload, toast]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': []
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: false
  });

  const resetError = () => {
    setError(null);
  };

  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer bg-white ${
        isDragActive ? "border-primary" : "border-gray-300 hover:border-primary"
      }`}
    >
      <div className="py-6">
        {/* Default state */}
        {!isLoading && !error && (
          <div id="upload-prompt" className="block">
            <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Drop your image here</h3>
            <p className="text-gray-500 mb-4">or</p>
            <button className="bg-primary hover:bg-indigo-700 text-white py-2 px-6 rounded-lg transition-colors font-medium">
              Select Image
            </button>
            <input {...getInputProps()} />
            <p className="text-gray-400 text-sm mt-4">
              Supports JPG, PNG, WEBP, GIF, and more
            </p>
            <p className="text-gray-400 text-sm">Max file size: 10MB</p>
          </div>
        )}

        {/* Loading state */}
        {isLoading && (
          <div className="block">
            <Loader2 className="mx-auto h-12 w-12 text-primary animate-spin mb-4" />
            <p className="text-gray-600">Uploading your image...</p>
          </div>
        )}

        {/* Error state */}
        {error && (
          <div className="block">
            <AlertCircle className="mx-auto h-12 w-12 text-red-500 mb-4" />
            <h3 className="text-xl font-semibold text-red-500 mb-2">
              Upload failed
            </h3>
            <p className="text-gray-600 mb-4">{error}</p>
            <button
              onClick={(e) => {
                e.stopPropagation();
                resetError();
              }}
              className="bg-primary hover:bg-indigo-700 text-white py-2 px-6 rounded-lg transition-colors font-medium"
            >
              Try Again
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
