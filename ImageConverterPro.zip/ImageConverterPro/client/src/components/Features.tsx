import React from "react";
import { Shield, Zap, Sliders } from "lucide-react";

export default function Features() {
  return (
    <section className="max-w-6xl mx-auto mt-16" id="features">
      <h2 className="text-2xl font-bold text-center mb-10">
        Why Choose ImageFormatify?
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="h-12 w-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <Shield className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Secure Processing</h3>
          <p className="text-gray-600">
            Your images are processed locally in your browser whenever possible.
            Nothing is stored on our servers.
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="h-12 w-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <Zap className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Lightning Fast</h3>
          <p className="text-gray-600">
            Our optimized conversion engine delivers your converted images
            within seconds.
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="h-12 w-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <Sliders className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Advanced Options</h3>
          <p className="text-gray-600">
            Fine-tune quality, compression, and other settings to get exactly
            the image you need.
          </p>
        </div>
      </div>
    </section>
  );
}
