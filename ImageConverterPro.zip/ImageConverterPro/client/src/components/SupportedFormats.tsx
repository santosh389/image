import React from "react";

interface FormatCardProps {
  format: string;
  description: string;
}

function FormatCard({ format, description }: FormatCardProps) {
  return (
    <div className="bg-white p-5 rounded-lg shadow-sm text-center">
      <div className="text-3xl font-bold text-primary mb-2">{format}</div>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  );
}

export default function SupportedFormats() {
  const formats = [
    { format: "JPG", description: "Ideal for photos" },
    { format: "PNG", description: "Perfect for transparency" },
    { format: "WEBP", description: "Optimize for web" },
    { format: "GIF", description: "Support for animations" },
    { format: "SVG", description: "Vector graphics" },
    { format: "TIFF", description: "High quality printing" },
    { format: "BMP", description: "Uncompressed format" },
    { format: "ICO", description: "Website favicon format" },
  ];

  return (
    <section className="max-w-6xl mx-auto mt-16" id="formats">
      <h2 className="text-2xl font-bold text-center mb-10">
        Supported Image Formats
      </h2>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
        {formats.map((item, index) => (
          <FormatCard
            key={index}
            format={item.format}
            description={item.description}
          />
        ))}
      </div>
    </section>
  );
}
