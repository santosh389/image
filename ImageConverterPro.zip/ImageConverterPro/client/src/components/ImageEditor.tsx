import React, { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Loader2, Download, Image as ImageIcon } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { ImageDetails } from "@/lib/imageUtils";
import { ImageConversionRequest, ImageConversionResponse } from "@shared/schema";

interface ImageEditorProps {
  originalImage: ImageDetails;
  convertedImage: ImageDetails | null;
  onConvert: (imageDetails: ImageDetails) => void;
  onReset: () => void;
}

type FormatOption = {
  value: string;
  label: string;
};

const formatOptions: FormatOption[] = [
  { value: "jpg", label: "JPG" },
  { value: "png", label: "PNG" },
  { value: "webp", label: "WEBP" },
  { value: "gif", label: "GIF" },
];

export default function ImageEditor({
  originalImage,
  convertedImage,
  onConvert,
  onReset,
}: ImageEditorProps) {
  const [selectedFormat, setSelectedFormat] = useState<string>("webp");
  const [quality, setQuality] = useState<number>(85);
  const [compression, setCompression] = useState<boolean>(true);
  const [removeMetadata, setRemoveMetadata] = useState<boolean>(false);
  const [convertToSRGB, setConvertToSRGB] = useState<boolean>(false);
  const { toast } = useToast();

  const convertMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest("POST", "/api/convert", data);
      return response.json() as Promise<ImageConversionResponse>;
    },
    onSuccess: (data) => {
      const convertedDetails: ImageDetails = {
        file: null, // We don't have the File object for the converted image
        url: data.url,
        format: data.format,
        size: data.size,
        dimensions: {
          width: data.width || 0,
          height: data.height || 0,
        },
        name: `converted.${data.format}`,
      };
      onConvert(convertedDetails);
      toast({
        title: "Image successfully converted!",
        description: `Your image has been converted to ${data.format.toUpperCase()}.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Conversion failed",
        description: error.message || "Failed to convert image. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleConvert = async () => {
    if (!originalImage.file) {
      toast({
        title: "Error",
        description: "Original image not found.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("image", originalImage.file);
    formData.append("format", selectedFormat);
    formData.append("quality", quality.toString());
    formData.append("compression", compression.toString());
    formData.append("removeMetadata", removeMetadata.toString());
    formData.append("convertToSRGB", convertToSRGB.toString());

    convertMutation.mutate(formData);
  };

  const handleDownload = () => {
    if (!convertedImage || !convertedImage.url) return;

    const link = document.createElement("a");
    link.href = convertedImage.url;
    link.download = `converted.${selectedFormat}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Image downloaded!",
      description: "Your converted image has been downloaded.",
    });
  };

  const formatSizeDisplay = (sizeInBytes: number): string => {
    const sizeInMB = sizeInBytes / (1024 * 1024);
    return `${sizeInMB.toFixed(1)} MB`;
  };

  const calculateSavings = (): string => {
    if (!convertedImage || !originalImage) return "";

    const originalSize = originalImage.size;
    const convertedSize = convertedImage.size;
    const percentageSaved = ((originalSize - convertedSize) / originalSize) * 100;

    if (percentageSaved <= 0) return "";

    return `${Math.round(percentageSaved)}% smaller`;
  };

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden">
      <CardContent className="p-0">
        <div className="p-6 border-b">
          <h2 className="text-2xl font-bold">Edit & Convert</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
          {/* Original image */}
          <div className="lg:col-span-1">
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Original Image</h3>
              <div className="bg-gray-100 rounded-lg p-2 h-64 flex items-center justify-center overflow-hidden">
                <img
                  src={originalImage.url}
                  alt="Original image preview"
                  className="max-w-full max-h-full object-contain"
                />
              </div>
              <div className="mt-2 text-sm text-gray-500">
                <span>{originalImage.format.toUpperCase()}</span> •{" "}
                <span>{formatSizeDisplay(originalImage.size)}</span> •{" "}
                <span>
                  {originalImage.dimensions.width} × {originalImage.dimensions.height}
                </span>
              </div>
            </div>
          </div>

          {/* Settings panel */}
          <div className="lg:col-span-1 space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-3">Target Format</h3>
              <div className="grid grid-cols-4 gap-2">
                {formatOptions.map((format) => (
                  <button
                    key={format.value}
                    className={`px-3 py-2 border rounded-md text-center hover:border-primary hover:text-primary transition-colors ${
                      selectedFormat === format.value
                        ? "bg-primary text-white"
                        : ""
                    }`}
                    onClick={() => setSelectedFormat(format.value)}
                  >
                    {format.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-3">Image Quality</h3>
              <div className="flex items-center">
                <span className="text-sm mr-2">Low</span>
                <Slider
                  value={[quality]}
                  min={1}
                  max={100}
                  step={1}
                  onValueChange={(values) => setQuality(values[0])}
                  className="w-full"
                />
                <span className="text-sm ml-2">High</span>
              </div>
              <div className="text-center text-sm mt-1 text-gray-600">
                <span>{quality}%</span>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-3">Optimization</h3>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="compression"
                    checked={compression}
                    onCheckedChange={(checked) => 
                      setCompression(checked as boolean)
                    }
                  />
                  <Label htmlFor="compression">Apply compression</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="metadata"
                    checked={removeMetadata}
                    onCheckedChange={(checked) =>
                      setRemoveMetadata(checked as boolean)
                    }
                  />
                  <Label htmlFor="metadata">Remove metadata</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="srgb"
                    checked={convertToSRGB}
                    onCheckedChange={(checked) =>
                      setConvertToSRGB(checked as boolean)
                    }
                  />
                  <Label htmlFor="srgb">Convert to sRGB</Label>
                </div>
              </div>
            </div>

            <Button
              onClick={handleConvert}
              className="w-full bg-primary hover:bg-indigo-700 text-white py-3 rounded-lg transition-colors font-medium"
              disabled={convertMutation.isPending}
            >
              {convertMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Converting...
                </>
              ) : (
                "Convert Image"
              )}
            </Button>
          </div>

          {/* Converted image preview */}
          <div className="lg:col-span-1">
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Converted Preview</h3>
              <div className="bg-gray-100 rounded-lg p-2 h-64 flex items-center justify-center overflow-hidden">
                {/* Empty state */}
                {!convertedImage && !convertMutation.isPending && (
                  <div className="text-center px-4">
                    <ImageIcon className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-500">
                      Your converted image will appear here
                    </p>
                  </div>
                )}

                {/* Loading state */}
                {convertMutation.isPending && (
                  <div className="text-center">
                    <Loader2 className="h-10 w-10 animate-spin mx-auto mb-2 text-primary" />
                    <p className="text-gray-600">Converting...</p>
                  </div>
                )}

                {/* Preview image */}
                {convertedImage && !convertMutation.isPending && (
                  <img
                    src={convertedImage.url}
                    alt="Converted image preview"
                    className="max-w-full max-h-full object-contain"
                  />
                )}
              </div>
              
              {convertedImage && (
                <div className="mt-2 text-sm text-gray-500">
                  <span>{selectedFormat.toUpperCase()}</span> •{" "}
                  <span>{formatSizeDisplay(convertedImage.size)}</span>{" "}
                  {calculateSavings() && (
                    <span className="text-green-500 font-medium">• {calculateSavings()}</span>
                  )}
                </div>
              )}
              
              {convertedImage && (
                <Button
                  onClick={handleDownload}
                  className="mt-4 w-full bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg transition-colors font-medium"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download Image
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
