import React from "react";
import { Link } from "wouter";
import { RefreshCcw } from "lucide-react";

export default function Header() {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <RefreshCcw className="text-primary h-6 w-6" />
          <h1 className="text-xl md:text-2xl font-bold text-gray-900">ImageFormatify</h1>
        </div>
        <nav>
          <ul className="flex space-x-6">
            <li className="hidden md:block">
              <Link href="/" className="text-gray-600 hover:text-primary">
                Home
              </Link>
            </li>
            <li className="hidden md:block">
              <Link href="/#features" className="text-gray-600 hover:text-primary">
                Features
              </Link>
            </li>
            <li>
              <Link href="/#faq" className="text-gray-600 hover:text-primary">
                Help
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
