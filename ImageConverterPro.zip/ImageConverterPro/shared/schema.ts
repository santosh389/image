import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Image conversion request schema
export const imageConversionSchema = z.object({
  format: z.enum(['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'tiff', 'bmp', 'ico']),
  quality: z.number().min(1).max(100).default(85),
  compression: z.boolean().default(true),
  removeMetadata: z.boolean().default(false),
  convertToSRGB: z.boolean().default(false),
});

export type ImageConversionRequest = z.infer<typeof imageConversionSchema>;

// Image conversion response
export const imageConversionResponseSchema = z.object({
  url: z.string(),
  format: z.string(),
  size: z.number(),
  width: z.number().optional(),
  height: z.number().optional(),
  originalSize: z.number(),
});

export type ImageConversionResponse = z.infer<typeof imageConversionResponseSchema>;
