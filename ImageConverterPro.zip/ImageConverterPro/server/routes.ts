import express, { type Express, Router } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { imageProcessor } from "./imageProcessor";
import multer from "multer";
import path from "path";
import fs from "fs";
import { imageConversionSchema, ImageConversionRequest } from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
  },
  fileFilter: (_req, file, cb) => {
    // Accept only image files
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = Router();
  
  // Ensure uploads directory exists
  const uploadsDir = path.join(process.cwd(), "dist/public/uploads");
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  
  // Serve uploaded files from the uploads directory
  app.use("/uploads", express.static(path.join(process.cwd(), "dist/public/uploads")));

  // Image conversion endpoint
  apiRouter.post("/convert", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      // Get and validate conversion options
      const conversionOptions: ImageConversionRequest = {
        format: req.body.format,
        quality: parseInt(req.body.quality || "85"),
        compression: req.body.compression === "true",
        removeMetadata: req.body.removeMetadata === "true",
        convertToSRGB: req.body.convertToSRGB === "true",
      };

      // Validate request parameters
      try {
        imageConversionSchema.parse(conversionOptions);
      } catch (error) {
        return res.status(400).json({ message: "Invalid conversion parameters", error });
      }

      // Process the image
      const processedImage = await imageProcessor.convertImage(
        req.file.buffer,
        conversionOptions
      );

      // Create a unique filename
      const timestamp = Date.now();
      const filename = `${timestamp}_converted.${conversionOptions.format}`;
      
      // Create uploads directory if it doesn't exist
      const uploadsDir = path.join(process.cwd(), "dist/public/uploads");
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      // Save the file to disk
      const filePath = path.join(uploadsDir, filename);
      fs.writeFileSync(filePath, processedImage.data);

      // Return the file URL and metadata
      res.json({
        url: `/uploads/${filename}`,
        format: conversionOptions.format,
        size: processedImage.data.length,
        width: processedImage.info.width,
        height: processedImage.info.height,
        originalSize: req.file.size,
      });
    } catch (error) {
      console.error("Image conversion error:", error);
      res.status(500).json({
        message: "Failed to convert image",
        error: (error as Error).message,
      });
    }
  });

  app.use("/api", apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}
