import sharp, { Sharp, OutputInfo } from "sharp";
import { ImageConversionRequest } from "@shared/schema";

interface ProcessedImage {
  data: Buffer;
  info: OutputInfo;
}

class ImageProcessor {
  async convertImage(
    imageBuffer: Buffer,
    options: ImageConversionRequest
  ): Promise<ProcessedImage> {
    try {
      // Start with basic Sharp instance
      let sharpInstance: Sharp = sharp(imageBuffer);

      // Apply options
      if (options.removeMetadata) {
        sharpInstance = sharpInstance.withMetadata({ exif: {} });
      }

      if (options.convertToSRGB) {
        sharpInstance = sharpInstance.toColorspace("srgb");
      }

      // Apply format-specific options
      switch (options.format) {
        case "jpg":
        case "jpeg":
          sharpInstance = sharpInstance.jpeg({
            quality: options.quality,
            progressive: true,
            optimizeCoding: options.compression,
          });
          break;
        
        case "png":
          sharpInstance = sharpInstance.png({
            quality: options.quality,
            progressive: true,
            compressionLevel: options.compression ? 9 : 6,
          });
          break;
        
        case "webp":
          sharpInstance = sharpInstance.webp({
            quality: options.quality,
            lossless: !options.compression,
          });
          break;
        
        case "gif":
          sharpInstance = sharpInstance.gif({
            // GIF doesn't support quality setting in the same way
            // but we can optimize it
            dither: options.compression ? 0 : 1,
          });
          break;
        
        case "tiff":
          sharpInstance = sharpInstance.tiff({
            quality: options.quality,
            compression: options.compression ? "lzw" : "none",
          });
          break;
        
        case "bmp":
          sharpInstance = sharpInstance.bmp();
          break;
        
        default:
          // Default to WebP for unsupported formats
          sharpInstance = sharpInstance.webp({
            quality: options.quality,
            lossless: !options.compression,
          });
      }

      // Generate the output buffer and metadata
      const { data, info } = await sharpInstance.toBuffer({ resolveWithObject: true });
      
      return { data, info };
    } catch (error) {
      console.error("Image processing error:", error);
      throw new Error(`Failed to process image: ${(error as Error).message}`);
    }
  }
}

export const imageProcessor = new ImageProcessor();
